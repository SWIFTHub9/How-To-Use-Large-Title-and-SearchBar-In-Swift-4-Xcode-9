//
//  ViewController.swift
//  How to use large title
//
//  Created by Abhishek Verma on 29/09/17.
//  Copyright © 2017 SWIFT HUB. All rights reserved.
//

import UIKit

class ViewController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        navigationController?.navigationBar.prefersLargeTitles = true
        
        let SearchController = UISearchController(searchResultsController: nil)
        navigationItem.searchController = SearchController
        navigationItem.hidesSearchBarWhenScrolling = false
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

